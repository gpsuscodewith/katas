﻿using System;
namespace BlazorChatApp.Shared
{
	public class Chat
	{
		public static readonly string DefaultRoute = "/chathub";


		public static class Methods
		{
			public const string GetMessage = "GetMessage";
		}
	}
}

